console.info("I am a.js")
;

console.info("I am b.js")

sum = function(a,b){
    return a+b
}
;
//


//

hi = function(){
  console.info('hi')
}

;
